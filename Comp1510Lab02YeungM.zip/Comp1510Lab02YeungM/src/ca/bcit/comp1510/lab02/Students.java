/**Students, print the thing
 * @author Marvin Yeung
 * @version 1
 */

package ca.bcit.comp1510.lab02;

public class Students {

    public static void main(String[] args) {
      // Drives the program
        
        System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"
                + "\n==\tStudent points\t\t=="
                + "\n\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////"
                + "\nName\t Lab\t Bonus\t Total"
                + "\n----\t ---\t -----\t -----"
                + "\nJoe\t 43\t 7\t 50"
                + "\nWilliam\t 50\t 8\t 58"
                + "\nMary Sue\t 39\t 10\t 49"
                + "\nPeng\t 87\t 6\t 93"
                + "\nKwon\t 99\t 0\t 99");

    }

}
