/**Circle, calculate circle things
 * @author Marvin Yeung
 * @version 3.141592654
 */

package ca.bcit.comp1510.lab02;

import java.util.Scanner;

public class Circle {

    public static void main(String[] args) {
        // Drives the program
        //@param args unused
        final int Pi = (int) 3.14159;
        double Radius;
        double Circumference;
        double Area;
        double doubleRadius;
        double Circumference2;
        double Area2;
        double CircumferenceIncrease;
        double AreaIncrease;
        
        Scanner myScanner = new Scanner(System.in);
        
        System.out.print("Enter the radius. ");
        Radius = myScanner.nextDouble();
        
        Circumference = 2 * Pi * Radius;
        Area = Pi * Radius * Radius;
        
        System.out.println("The circumference is " + Circumference);
        System.out.println("The area is " + Area);
        
        
        doubleRadius = 2 * Radius;
        Circumference2 = 2 * Pi * doubleRadius;
        Area2 = Pi * doubleRadius * doubleRadius;
        CircumferenceIncrease = Circumference2 / Circumference;
        AreaIncrease = Area2 / Area;
        
        System.out.println("The circumference increased " + CircumferenceIncrease + "x and the area increased "
                + AreaIncrease +"x when the radius doubled. ");
        
    }

}
