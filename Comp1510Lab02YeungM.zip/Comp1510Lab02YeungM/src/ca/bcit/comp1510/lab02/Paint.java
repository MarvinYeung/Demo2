/**Paint, calculate how many cans of paint needed
 * @author Marvin Yeung
 * @version 1
 */

package ca.bcit.comp1510.lab02;

import java.util.Scanner;

public class Paint {

    public static void main(String[] args) {
        // Drives the program
        
        final int COVERAGE = 400;
        double length;
        double width;
        double height;
        double coats;
        double surfaceArea;
        double coverageNeeded;
        double cansOfPaintNeeded;
        
        Scanner myScanner = new Scanner (System.in);
        
        System.out.println("Enter the length of the room in feet. ");
        length = myScanner.nextDouble();
        System.out.println("Enter the width of the room in feet. ");
        width = myScanner.nextDouble();
        System.out.println("Enter the height of the room in feet. ");
        height = myScanner.nextDouble();
        System.out.println("Enter the coats");
        coats = myScanner.nextDouble();
        
        surfaceArea = length * width + width * height * 2 + height * length * 2;
        coverageNeeded = surfaceArea * coats;
        cansOfPaintNeeded = coverageNeeded / COVERAGE;
        
        System.out.println("You need " + cansOfPaintNeeded + "cans of paint. ");

    }

}
