package ca.bcit.comp1510.lab02;
import java.util.Scanner;
/**
* BaseConvert.
*
* @author BCIT
* @version 1.0
*/
public class BaseConvert {
/**
* Drives the program.
*
* @param args
* arguments
*/
public static void main(String[] args) {
int base10number; // the number in base 10
int base; // the new base
int maximumNumber = 0; // the maximum number that will fit
// in 4 digits in the new base
int place0; // digit in the 1's (base^0) place
int place1;
int place2;
int place3;
int remainder;
Scanner scan = new Scanner(System.in);
System.out.println("Base Conversion Program");
System.out.print("Please enter a base (2-9): ");
base = scan.nextInt();// Assign the user's input to the base variable
maximumNumber = base * base * base * base - 1;// Calculate the correct value to store in maxNumber
System.out.println("The max base 10 number to convert for that base is " + maximumNumber);
System.out.println("Please enter a base 10 number to convert: ");
base10number = scan.nextInt();// Assign the user's input to the base10number variable
// Do the conversion
place0 = base10number % base;
remainder = base10number / base;
place1 = remainder % base;
remainder /= base;
place2 = remainder % base;
remainder /= base;
place3 = remainder % base;
System.out.println("The number " + base10number + " in base " + base 
        + " is " + place3 + place2 + place1 + place0);

String baseBNumber = new String(""); // the number in the new base
scan.close();
}
}