import java.util.random.RandomGenerator;

/** Dice, roll random numbers. 
 *  @author Marvin Yeung
 *  @version 1.0
 */

public class Dice {
    
    /*  Drives the program.
     *  @param args unused
     */

    public static void main(String[] args) {
        RandomGenerator generator = RandomGenerator.getDefault();
        int num1;
        int num2;
        int num3;
        int num4;
        int num5;
        int num6;
        final int four = 4;
        final int six = 6;
        final int eight = 8;
        final int ten = 10;
        final int twelve = 12;
        final int twenty = 20;
        int total;
        
        num1 = generator.nextInt(four) + 1;
        System.out.println("4-sided dice rolled: " + num1);
        num2 = generator.nextInt(six) + 1;
        System.out.println("6-sided dice rolled: " + num2);
        num3 = generator.nextInt(eight) + 1;
        System.out.println("8-sided dice rolled: " + num3);
        num4 =  generator.nextInt(ten) + 1;
        System.out.println("10-sided dice rolled: " + num4);
        num5 = generator.nextInt(twelve) + 1;
        System.out.println("12-sided dice rolled: " + num5);
        num6 = generator.nextInt(twenty) + 1;
        System.out.println("20-sided dice rolled: " + num6);
        total = num1 + num2 + num3 + num4 + num5 + num6;
        System.out.println("The total sum of rolls is: " + total);

    }

}
