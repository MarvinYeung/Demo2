import java.util.Scanner;

/** FunWithStrings, print book name in different ways. 
 *  @author Marvin Yeung
 *  @version 1.0
 */
public class FunWithStrings {
    
    /*  Drives the program.
     *  @param args unused
     */
    
    public static void main(String[] args) {
        
        String bookname;
        String trimmedUserInput;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Please enter your favourite book name");
        bookname = scan.nextLine();
        
        System.out.println(bookname);
        System.out.println("Length of string: " + bookname.length());
        System.out.println("Does it start with \"The\": " 
                + bookname.startsWith("The"));
        System.out.println("toUpperCase: " + bookname.toUpperCase());
        System.out.println("toLowerCase: " + bookname.toLowerCase());
        
        trimmedUserInput = bookname.trim();
        System.out.println("trimmed: " + trimmedUserInput);
        
        bookname = trimmedUserInput.toLowerCase();
        String firstLetter = (bookname.length() > 0) 
                ? bookname.substring(0, 1).toUpperCase() : "";
        String lastLetter = (bookname.length() > 1) 
                ? bookname.substring(bookname.length() - 1).toUpperCase() : "";
        String middle = (bookname.length() > 2) 
                ? bookname.substring(1, bookname.length() - 1) : "";
        System.out.println("Final output: "
                + firstLetter + middle + lastLetter);
        
        /* 10. In this case, using scan.next works exact same as scan.nextLine
         * since there is no previous typed things. 
         * 
         * 14. No, printing bookname.toUpperCase() won't change it permanently. 
         * 
         * 15. Yes, storing it using toUpperCase() will change it permanently. 
         */

    }

}
