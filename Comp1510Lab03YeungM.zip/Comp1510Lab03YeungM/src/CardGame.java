import java.util.random.RandomGenerator;

/** Dice, calculates the distance between two points.
 *  @author Marvin Yeung
 *  @version 1.0
 */

public class CardGame {
    
    /*  Drives the program.
     *  @param args unused
     */
    
    enum Rank{
        //ace
        ace,
        //two
        two,
        //three
        three,
        //four
        four,
        //five
        five,
        //six
        six,
        //seven
        seven,
        //eight
        eight,
        //nine
        nine,
        //ten
        ten,
        //jack
        jack,
        //queen
        queen,
        //king
        king
    }
    
    enum Suit{
        //hearts
        hearts,
        //diamonds
        diamonds,
        //clubs
        clubs,
        //spades
        spades
    }

    public static void main(String[] args) {
        RandomGenerator generator = RandomGenerator.getDefault();
        int randomRankChoice = generator.nextInt(Rank.values().length);
        Rank randomRank = Rank.values()[randomRankChoice];
        int randomSuitChoice = generator.nextInt(Suit.values().length);
        Suit randomSuit = Suit.values()[randomSuitChoice];
        System.out.println(randomRank + " " + randomSuit);

    }

}
