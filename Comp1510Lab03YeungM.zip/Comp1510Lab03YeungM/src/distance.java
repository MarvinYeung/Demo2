import java.text.DecimalFormat;
import java.util.Scanner;

/** Dice, calculates the distance between two points.
 *  @author Marvin Yeung
 *  @version 1.0
 */

public class distance {
    
    /*  Drives the program.
     *  @param args unused
     */

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter x1 and y1 "
                + "with white space in between");
        double x1 = scan.nextDouble();
        double y1 = scan.nextDouble();
        System.out.println("Please enter x2 and y2 "
                + "with white space in between");
        double x2 = scan.nextDouble();
        double y2 = scan.nextDouble();
        double distance = Math.sqrt((x2 - x1) * (x2 - x1) 
                + (y2 - y1) * (y2 - y1));
        DecimalFormat fmt = new DecimalFormat("#.##");
        System.out.println("The distance is " + fmt.format(distance));

    }

}
