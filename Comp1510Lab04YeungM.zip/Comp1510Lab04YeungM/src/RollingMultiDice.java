import java.util.Scanner;

/**
 * run MultiDie. 
 * @author Marvin Yeung
 * @version 1.0
 */

public class RollingMultiDice {

    /** Drives the program.
     * @param args unused
     */
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter number of sides: ");
        int numSides = scan.nextInt();
        
        MultiDie die = new MultiDie(numSides);
        System.out.println("Roll: " + die.roll());
        
        /*
         * 1. No, you don't need a getter or setter. 
         * 2. You can have a getter, not setter though. 
         * 3. Because it is not supposed to change. 
         * 4. It is constructed
         * 5. Yes. 
         * 6. No because we don't want it to become final instance variables. 
         */
    }
}
