import java.util.Scanner;

/** run Name. 
 * @author Marvin Yeung
 * @version 1.0
 */
public class Names {

    /** Drives the program. 
     * @param args unused
     */
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter first name: ");
        String first = scan.next();
        System.out.print("Enter middle name: ");
        String middle = scan.next();
        System.out.print("Enter last name: ");
        String last = scan.next();
        
        Name myName = new Name(first, middle, last);
        
        System.out.println(myName.toString());

    }

}
