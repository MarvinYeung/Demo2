/** 
 * student info.
 * @author Marvin Yeung
 * @version 1.0
 */
public class Student {
    
    /** firstname. */
    private String firstName;
    
    /** lastname. */
    private String lastName;
    
    /** year of birth. */
    private int birthYear;
    
    /** student number. */
    private String studentNumber;
    
    /** gpa. */
    private int gpa;
    
    /**
     * Student constructor.
     * @param first firstname
     * @param last lastname
     * @param yearOfBirth birth year
     * @param id number
     * @param studentGPA gpa
     */
    public Student(
            String first, 
            String last, 
            int yearOfBirth,
            String id,
            int studentGPA
    ) {
        firstName = first;
        lastName = last;
        birthYear = yearOfBirth;
        studentNumber = id;
        gpa = studentGPA;
    }

    /**
     * return firstname.
     * @return firstname
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * update firstname.
     * @param firstName set firstname
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * return lastname.
     * @return lastname
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * update lastname.
     * @param lastName set lastname
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * return birthyear.
     * @return birthyear
     */
    public int getBirthYear() {
        return birthYear;
    }

    /**
     * update birthyear.
     * @param birthYear set birthyear
     */
    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    /**
     * return GPA.
     * @return GPA
     */
    public int getGradeAverage() {
        return gpa;
    }

    /**
     * update GPA.
     * @param newGPA set GPA
     */
    public void setGradeAverage(int newGPA) {
        this.gpa = newGPA;
    }
 
    /**
     * return studentnumber.
     * @return studentnumber
     */
    public String getStudentNumber() {
        return studentNumber;
    }
    
    /**
     * update studentnumber.
     * @param studentNumber set studentnumber
     */
    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }
    
    /**
     * student info.
     * @return student info
     */
    public String toString() {
        return firstName + " "
                + lastName + " "
                + birthYear + " "
                + studentNumber + " "
                + gpa;
    }
}
