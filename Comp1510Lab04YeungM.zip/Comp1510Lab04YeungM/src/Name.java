
/** Store names.
 * @author Marvin Yeung
 * @version 1.0
 */
public class Name {
    /** first name. */
    private String first;

    /** middle name. */
    private String middle;
    
    /** last name. */
    private String last;
    
    /** name constructor. 
     * @param firstname stores first name
     * @param middlename stores middle name
     * @param lastname stores last name
     */
    public Name(String firstname, String middlename, String lastname) {
        first = firstname;
        middle = middlename;
        last = lastname;
    }
    
    /** getfirst. 
     * @return firstname
     */
    public String getfirst() {
        return first;
    }
    
    /** getmiddle. 
     * @return middlename
     */
    public String getmiddle() {
        return middle;
    }
    
    /** getlast. 
     * @return lastname
     */
    public String getlast() {
        return last;
    }
    
    /** compiles the name.
     * @return the name
     */
    public String toString() {
        return first + " " + middle + " " + last;
    }
}
