import java.util.Scanner;

/** Convert the interger to binary, octal and hexadecimal. 
 *  @author Marvin Yeung
 *  @version 1.0
 */

public class IntegerWrapper {
    
    /**  Drives the program.
     *  @param args unused
     */

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter an integer");
        int number = scan.nextInt();
        System.out.println("Binary: " + Integer.toBinaryString(number));
        System.out.println("Octal: " + Integer.toOctalString(number));
        System.out.println("Hexadecimal " + Integer.toHexString(number));
        System.out.println("Max value: " + Integer.MAX_VALUE);
        System.out.println("Min value: " + Integer.MIN_VALUE);
        System.out.println("Please enter an integer");
        String number2 = scan.next();
        System.out.println("Please enter an integer");
        String number3 = scan.next();
        int a = Integer.parseInt(number2);
        int b = Integer.parseInt(number3);
        System.out.println(a + " + " + b + " = " + (a + b));
        
    }

}
