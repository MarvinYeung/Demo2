public class Simple {
    /**
     * @param args
     */
public static void main(String[] args) {
    System.out.println("I love Java");
    /** simple: Type with same name but different case exists
     * SimpleProgram: works
     * 1 Simple: Type name is not valid. The type name '1 Simple' is not a valid identifier
     * _Simple_: works
     * *Simple*:  Type name is not valid. The type name '*Simple*' is not a valid identifier
     * $123_45: works
     * Simple!:  Type name is not valid. The type name 'Simple!' is not a valid identifier
     * 
     * It cannot start with numbers, contain "*" or "!". 
     */
    }
}