/** Count one to five in English, French, and Spanish
         * @author Marvin Yeung
         * @version 1
         */
public class Count {
    

    public static void main(String[] args) {
        System.out.println("one two three four five");
        System.out.println("un deux trois quatre cinq");
        System.out.println("uno dos tres cuatro cinco");
        /**
         * 8: "Use "this" instead of "the" when referring to an object created from the current class."
         *   "Use 3rd person (descriptive) not 2nd person (prescriptive)."
         */
    }

}
