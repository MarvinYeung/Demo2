    /**
    * Prints a Hello World message.
    *
    * @author BCIT
    * @version 2022
    */
    public class Hello {
    /**
    * Prints the greeting.
    *
    * @param args
    * unused
    */
    public static void main(String[] args) {
    System.out.println("Hello world!");
    /**
     * a. Error: Could not find or load main class Hello
    Caused by: java.lang.ClassNotFoundException: Hello
     * b. It only changed the printed message which can be anything, changing it won't create any error. 
     * c. Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
    String literal is not properly closed by a double-quote

    at Hello.main(Hello.java:15)

     * d. Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
    Syntax error on token(s), misplaced construct(s)
    Syntax error on token "!", ; expected
    String literal is not properly closed by a double-quote

    at Hello.main(Hello.java:15)
     * e. Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
    Syntax error, insert ";" to complete BlockStatements

    at Hello.main(Hello.java:15)

     */
    }
    }