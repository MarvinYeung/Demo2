[Marvin Yeung], [A01347279], [B], [February 6th, 2025]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[100% complete]

------------------------
Question two (Sqrt) status:

[100% complete]

------------------------
Question three (Reverse) status:

[100% complete]

------------------------
Question four (Pack) status:

[100% complete]
